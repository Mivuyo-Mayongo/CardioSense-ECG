# CardioSense redesign

## Run
1. Open a terminal in this folder.
2. Run `python -m pip install -r requirements.txt`.
3. Run `python app.py`.
4. Open http://127.0.0.1:5000 and sign in with **cardiosense / 1234**.

Connect the ESP32 over USB and close Arduino Serial Monitor before running the app. Port auto-detection is retained. To select a port in PowerShell, run `$env:CARDIOSENSE_SERIAL_PORT="COM5"` before starting the app.

Optional PowerShell settings before starting:
- `$env:CARDIOSENSE_USERNAME="yourname"`
- `$env:CARDIOSENSE_PASSWORD="your-password"`
- `$env:CARDIOSENSE_SECRET_KEY="a-long-random-private-value"` (keeps sessions valid across restarts)

The included login is for a local student prototype. It uses one configured account, signed sessions and form tokens; no registration or password-reset service is included. Use HTTPS and a production server before any remote deployment.

## ESP32
The sketch is preserved byte-for-byte in `CardioSense_ESP32/CardioSense_ESP32.ino`. Keep your existing `model_standardized.h` and `model_metadata.h` in that sketch folder and retain your installed tflm_esp32 and eloquent_tinyml libraries. Those model files were not supplied. Existing wiring, 360 Hz sampling, 200-point inference, LEDs, physical button and buzzer behavior remain unchanged. Browser notification/vibration settings control the browser only, not the hardware buzzer.

## Design and retained behavior
The original HTML was a narrow phone dashboard without login. The new split login follows the supplied burgundy/warm-white reference; the heart illustration is a bundled vector interpretation, rather than the exact reference artwork. Desktop uses a fixed burgundy sidebar; mobile keeps bottom navigation. Light/dark mode, ECG charts, latest beat, TinyML results, date/filter history and settings remain available.

History retains the original browser-local storage (up to 100 entries/day and 30 days); it is not an account database and remains on the browser after sign-out. Classification and BPM values come from the original backend/ESP32, with no generated patient data. Chart.js and Google Fonts require internet access, as in the uploaded page.

## Verification
Flask checks cover invalid/valid login, protected page/data endpoint, sign-out, ECG parsing, BPM, normal/abnormal TinyML messages and lead disconnection. JavaScript syntax checked with Node. Physical hardware and Arduino compilation require your ESP32 and missing model headers.

Automated browser layout checks were attempted but blocked by the local environment browser/network restrictions; visual and real-hardware verification remain to be done.
