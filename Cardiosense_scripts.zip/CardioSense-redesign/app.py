from collections import deque
from flask import Flask, render_template, jsonify, request
import os
import secrets
import hmac
from functools import wraps
from flask import session, redirect, url_for
import re
import serial
from serial.tools import list_ports
import threading
import time

app = Flask(__name__, root_path=os.path.dirname(os.path.abspath(__file__)))
app.secret_key = os.getenv("CARDIOSENSE_SECRET_KEY") or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
LOGIN_USER = os.getenv("CARDIOSENSE_USERNAME", "cardiosense")
LOGIN_PASSWORD = os.getenv("CARDIOSENSE_PASSWORD", "1234")

@app.before_request
def protect_dashboard():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(24)
    if request.endpoint in ("login", "static"):
        return
    if not session.get("authenticated"):
        if request.path == "/ecg-data":
            return jsonify({"error": "Sign in required"}), 401
        return redirect(url_for("login"))

@app.after_request
def prevent_private_caching(response):
    if request.endpoint != "static":
        response.headers["Cache-Control"] = "no-store"
    return response

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        if not hmac.compare_digest(request.form.get("csrf", ""), session["csrf"]):
            error = "Your sign-in form expired. Please try again."
        elif (hmac.compare_digest(request.form.get("username", ""), LOGIN_USER)
              and hmac.compare_digest(request.form.get("password", ""), LOGIN_PASSWORD)):
            session.clear()
            session["authenticated"] = True
            session["csrf"] = secrets.token_hex(24)
            return redirect(url_for("home"))
        else:
            error = "The username or password is incorrect."
    return render_template("login.html", error=error,
        prototype=LOGIN_USER == "cardiosense" and LOGIN_PASSWORD == "1234")

@app.post("/logout")
def logout():
    if not hmac.compare_digest(request.form.get("csrf", ""), session.get("csrf", "")):
        return "Invalid form", 400
    session.clear()
    return redirect(url_for("login"))


# Set CARDIOSENSE_SERIAL_PORT (for example COM5) to override auto-detection.
PREFERRED_SERIAL_PORT = os.getenv("CARDIOSENSE_SERIAL_PORT", "").strip()
SERIAL_PORT = PREFERRED_SERIAL_PORT or "Searching..."
BAUD_RATE = 115200
SAMPLE_RATE = 360
PRE_PEAK = 90
POST_PEAK = 109
BEAT_SIZE = 200

state_lock = threading.Lock()
sample_queue = deque(maxlen=4000)
sample_history = deque(maxlen=4000)
peak_queue = deque(maxlen=100)
recent_predictions = deque(maxlen=8)

sample_index = -1
esp32_connected = False
last_sample_time = 0.0
last_error = None
pending_peak = None
previous_peak = None
heart_rate = None
latest_beat = []
latest_peak_value = None
ai_status = "Waiting..."
prediction_score = None
confidence = None
clipped_samples = 0
signal_quality = "Waiting for heartbeat"
leads_connected = None
measurement_started_at = None
beats_in_last_window = None

# These thresholds were selected using record-separated validation patients.
UNCERTAIN_LOW = 0.45
UNCERTAIN_HIGH = 0.55


def find_esp32_port():
    """Find the ESP32 CP210x serial adapter while ignoring the Arduino Uno."""
    ports = list(list_ports.comports())

    if PREFERRED_SERIAL_PORT:
        preferred = PREFERRED_SERIAL_PORT.casefold()
        for port in ports:
            if port.device.casefold() == preferred:
                return port.device

    preferred_markers = ("cp210", "silicon labs", "usb to uart")
    for port in ports:
        description = f"{port.description} {port.manufacturer or ''}".casefold()
        if any(marker in description for marker in preferred_markers):
            return port.device

    # If only one serial device is connected, it is safe to try it.
    if len(ports) == 1:
        return ports[0].device

    return None


def classify_model_score(score):
    if score <= UNCERTAIN_LOW:
        return "NORMAL (N-like)"
    if score >= UNCERTAIN_HIGH:
        return "ABNORMAL (V-like)"
    return "UNCERTAIN"


def classify_bpm(bpm):
    if bpm is None:
        return "WAITING"
    if bpm < 60:
        return "LOW"
    if bpm > 100:
        return "HIGH"
    return "WITHIN RANGE"


def update_beat_if_ready():
    global pending_peak, latest_beat, clipped_samples, signal_quality

    if pending_peak is None or sample_index < pending_peak + POST_PEAK:
        return

    history_map = dict(sample_history)
    start = pending_peak - PRE_PEAK
    indices = range(start, pending_peak + POST_PEAK + 1)

    if all(index in history_map for index in indices):
        beat = [history_map[index] for index in indices]
        if len(beat) == BEAT_SIZE:
            latest_beat = beat
            clipped_samples = sum(value <= 5 or value >= 4090 for value in beat)
            signal_quality = "Clipping detected" if clipped_samples else "Good amplitude range"

    pending_peak = None


def process_serial_line(line):
    global sample_index, last_sample_time, pending_peak, previous_peak
    global heart_rate, latest_peak_value, ai_status, prediction_score, confidence
    global leads_connected, signal_quality, latest_beat, pending_peak, previous_peak
    global measurement_started_at, beats_in_last_window

    if line == "LEADS,DISCONNECTED":
        leads_connected = False
        heart_rate = None
        latest_peak_value = None
        ai_status = "AI PAUSED"
        prediction_score = None
        confidence = None
        latest_beat = []
        pending_peak = None
        previous_peak = None
        sample_queue.clear()
        sample_history.clear()
        peak_queue.clear()
        recent_predictions.clear()
        measurement_started_at = None
        beats_in_last_window = None
        signal_quality = "Electrodes disconnected"
        return

    if line == "LEADS,CONNECTED":
        leads_connected = True
        heart_rate = None
        latest_peak_value = None
        ai_status = "WAITING"
        prediction_score = None
        confidence = None
        latest_beat = []
        pending_peak = None
        previous_peak = None
        measurement_started_at = time.time()
        beats_in_last_window = None
        signal_quality = "Waiting for valid ECG"
        return

    if line.startswith("BPM30,"):
        if leads_connected is False:
            return
        try:
            _, bpm_text, beats_text = line.split(",", 2)
            measured_bpm = float(bpm_text)
            measured_beats = int(beats_text)
        except (ValueError, IndexError):
            return

        heart_rate = round(measured_bpm)
        beats_in_last_window = measured_beats
        measurement_started_at = time.time()
        return

    if line.startswith("ECG,"):
        if leads_connected is False:
            return
        try:
            value = int(line.split(",", 1)[1])
        except (ValueError, IndexError):
            return

        sample_index += 1
        last_sample_time = time.time()
        if measurement_started_at is None:
            measurement_started_at = last_sample_time
        sample_queue.append([sample_index, value])
        sample_history.append((sample_index, value))
        update_beat_if_ready()
        return

    if line.startswith("R-peak detected:"):
        if leads_connected is False:
            return
        try:
            peak_value = int(line.split(":", 1)[1].strip())
        except (ValueError, IndexError):
            return

        peak_index = max(0, sample_index - 1)
        latest_peak_value = peak_value
        pending_peak = peak_index
        peak_queue.append([peak_index, peak_value])

        previous_peak = peak_index
        return

    if line.startswith("RESULT,"):
        if leads_connected is False:
            return

        try:
            _, beat_id_text, bpm_text, score_text, label = line.split(",", 4)
            beat_id = int(beat_id_text)
            raw_bpm = float(bpm_text)
            score = float(score_text)
        except (ValueError, IndexError):
            return

        paired_bpm = heart_rate
        prediction_score = score
        # Strength describes distance toward the selected N-like or V-like class.
        # It is a model output, not a medical probability or clinical confidence.
        confidence = round((1.0 - score if score < 0.5 else score) * 100.0, 2)
        ai_status = classify_model_score(score)
        recent_predictions.appendleft({
            "beat_id": beat_id,
            "time": time.strftime("%H:%M:%S"),
            "status": ai_status,
            "score": round(score, 6),
            "confidence": confidence,
            "bpm": paired_bpm,
            "raw_bpm": round(raw_bpm) if raw_bpm > 0 else None,
        })
        return

    if line.startswith("Prediction score:"):
        if leads_connected is False:
            return
        match = re.search(r"Prediction score:\s*([0-9.eE+-]+)\s*->\s*(.+)", line)
        if not match:
            return

        score = float(match.group(1))
        label = match.group(2).strip()
        prediction_score = score
        confidence = round((1.0 - score if score < 0.5 else score) * 100.0, 2)
        ai_status = classify_model_score(score)
        recent_predictions.appendleft({
            "time": time.strftime("%H:%M:%S"),
            "status": ai_status,
            "score": round(score, 6),
            "bpm": heart_rate,
        })


def read_esp32():
    global esp32_connected, last_error, SERIAL_PORT

    while True:
        try:
            detected_port = find_esp32_port()
            if not detected_port:
                raise RuntimeError(
                    "ESP32 CP210x port not found. Connect the ESP32 or set "
                    "CARDIOSENSE_SERIAL_PORT."
                )

            SERIAL_PORT = detected_port
            print(f"Connecting to ESP32 on {SERIAL_PORT}...")
            with serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1) as ser:
                time.sleep(2)
                ser.reset_input_buffer()
                with state_lock:
                    esp32_connected = True
                    last_error = None
                print("ESP32 connected successfully.")

                while True:
                    raw = ser.readline()
                    if not raw:
                        continue
                    line = raw.decode("utf-8", errors="ignore").strip()
                    if line:
                        with state_lock:
                            process_serial_line(line)
        except Exception as error:
            with state_lock:
                esp32_connected = False
                last_error = str(error)
            print(f"ESP32 connection error: {error}")
            time.sleep(3)


if os.getenv("CARDIOSENSE_DISABLE_SERIAL") != "1":
    threading.Thread(target=read_esp32, daemon=True).start()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/ecg-data")
def get_ecg_data():
    with state_lock:
        # Each browser keeps its own last received sample index. Do not clear
        # the shared buffers: clearing them allowed one device to consume ECG
        # data before another device (for example, phone before laptop).
        after = request.args.get("after", default=-1, type=int)
        samples = [item for item in sample_history if item[0] > after]
        peaks = [item for item in peak_queue if item[0] > after]

        # Limit a newly opened page to a useful visible window.
        if len(samples) > 720:
            samples = samples[-720:]
        serial_connected = esp32_connected
        signal_recent = time.time() - last_sample_time < 3.0
        connected = serial_connected and signal_recent
        electrodes_connected = leads_connected is not False

        if not signal_recent and leads_connected is not False:
            current_bpm = None
            current_status = "WAITING"
            current_score = None
            current_confidence = None
            current_quality = "Waiting for ECG data"
        else:
            current_bpm = heart_rate
            current_status = ai_status
            current_score = prediction_score
            current_confidence = confidence
            current_quality = signal_quality

        if electrodes_connected and current_bpm is None and measurement_started_at:
            elapsed = max(0, time.time() - measurement_started_at)
            seconds_remaining = max(0, 30 - int(elapsed))
            bpm_status = f"Measuring... {seconds_remaining} seconds remaining"
        else:
            seconds_remaining = 0
            bpm_status = classify_bpm(current_bpm) if electrodes_connected else "PAUSED"

        return jsonify({
            "samples": samples,
            "peaks": peaks,
            "connected": connected,
            "serial_connected": serial_connected,
            "port": SERIAL_PORT,
            "bpm": current_bpm if electrodes_connected else None,
            "bpm_status": bpm_status,
            "bpm_window_seconds": 30,
            "bpm_seconds_remaining": seconds_remaining,
            "beats_in_last_window": beats_in_last_window,
            "ai_status": current_status if electrodes_connected else "AI PAUSED",
            "prediction_score": current_score if electrodes_connected else None,
            "confidence": current_confidence if electrodes_connected else None,
            "beat": latest_beat if electrodes_connected else [],
            "peak_position": PRE_PEAK,
            "peak_value": latest_peak_value,
            "clipped_samples": clipped_samples,
            "signal_quality": current_quality if electrodes_connected else "Electrodes disconnected",
            "electrodes_connected": electrodes_connected,
            "recent_predictions": list(recent_predictions),
            "error": last_error,
        })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)

