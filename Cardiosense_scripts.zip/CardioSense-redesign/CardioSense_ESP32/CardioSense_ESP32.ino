#include <Arduino.h>
#include <math.h>
#include <string.h>
#include "model_standardized.h"
#include "model_metadata.h"
#include <tflm_esp32.h>
#include <eloquent_tinyml.h>

// ---------- Hardware and acquisition ----------
// Current breadboard wiring
const int ECG_PIN = 34;
const int LO_PLUS_PIN = 32;
const int LO_MINUS_PIN = 33;
const int RED_PIN = 25;
const int GREEN_PIN = 26;
const int BLUE_PIN = 27;
const int BUTTON_PIN = 14;
const int BUZZER_PIN = 13;

const uint32_t BUTTON_DEBOUNCE_MS = 50;
const uint32_t NORMAL_BEEP_ON_MS = 100;
const uint32_t NORMAL_BEEP_OFF_MS = 900;
const uint32_t ALARM_BEEP_ON_MS = 700;
const uint32_t ALARM_BEEP_OFF_MS = 250;
const uint32_t SAMPLE_PERIOD_US = 1000000UL / 360UL;
const uint32_t LEAD_DEBOUNCE_MS = 150;
const uint32_t DISCONNECTED_REPORT_INTERVAL_MS = 1000;
const uint32_t HEART_RATE_WINDOW_MS = 30000;

// 0.5-40 Hz band-pass plus a 50 Hz mains notch at 360 samples/second.
// This cleans the displayed signal and makes R-peak detection less sensitive
// to baseline movement, clothing friction and electrical interference.
struct Biquad {
  float b0;
  float b1;
  float b2;
  float a1;
  float a2;
  float z1;
  float z2;

  Biquad(
    float coefficientB0,
    float coefficientB1,
    float coefficientB2,
    float coefficientA1,
    float coefficientA2
  ) {
    b0 = coefficientB0;
    b1 = coefficientB1;
    b2 = coefficientB2;
    a1 = coefficientA1;
    a2 = coefficientA2;
    z1 = 0.0f;
    z2 = 0.0f;
  }

  float process(float input) {
    float output = b0 * input + z1;

    z1 = b1 * input - a1 * output + z2;
    z2 = b2 * input - a2 * output;

    return output;
  }

  void reset() {
    z1 = 0.0f;
    z2 = 0.0f;
  }
};

Biquad bandPassLowPass(
  0.07876235329f,
  0.1575247066f,
  0.07876235329f,
  -1.067092429f,
  0.3842342474f
);

Biquad bandPassHighPass(
  1.0f,
  -2.0f,
  1.0f,
  -1.987664221f,
  0.987741721f
);

Biquad mainsNotch50Hz(
  0.9856631004f,
  -1.267144056f,
  0.9856631004f,
  -1.267144056f,
  0.9713262007f
);

float filterEcg(int rawSample) {
  float value = bandPassLowPass.process((float) rawSample);
  value = bandPassHighPass.process(value);
  return mainsNotch50Hz.process(value);
}

// ---------- Verified training configuration ----------
const int MODEL_INPUTS = 200;
const int MODEL_OUTPUTS = 1;
const int PEAK_POSITION = 90;
const int POST_PEAK_SAMPLES = 109;

// Must match the per-beat standardization used to train the standardized model.
const float STANDARDIZATION_EPSILON = 1e-6f;

static_assert(MODEL_INPUTS == ECG_MODEL_INPUTS, "Model input-size mismatch");
static_assert(PEAK_POSITION == ECG_PEAK_POSITION, "Model peak-position mismatch");

// ---------- Adaptive, polarity-independent peak detector ----------
// 0.30 seconds permits rates up to 200 BPM while suppressing double detection.
const uint32_t REFRACTORY_SAMPLES = 108;
const float BASELINE_ALPHA = 0.01f;
const float MIN_PEAK_DEVIATION = 80.0f;
const float MIN_PEAK_SLOPE = 20.0f;

// ---------- TinyML ----------
// Larger than the earlier loading-only test because inference needs working RAM.
const int TENSOR_ARENA_SIZE = 80 * 1024;
const int MODEL_OPERATOR_COUNT = 9;
Eloquent::TF::Sequential<MODEL_OPERATOR_COUNT, TENSOR_ARENA_SIZE> ml;

// ---------- Streaming buffers ----------
const int HISTORY_SIZE = 256;
int historyBuffer[HISTORY_SIZE];
int historyWriteIndex = 0;
uint32_t samplesReceived = 0;

float heartbeat[MODEL_INPUTS];
float modelInput[MODEL_INPUTS];
int heartbeatPosition = 0;
bool collectingHeartbeat = false;

int sampleTwoBack = 0;
int sampleOneBack = 0;
float deviationTwoBack = 0.0f;
float deviationOneBack = 0.0f;
float runningBaseline = 2048.0f;
float signalLevel = 300.0f;
float noiseLevel = 40.0f;
float slopeLevel = 50.0f;
bool detectorInitialized = false;
bool haveTwoPreviousSamples = false;
uint32_t lastPeakSample = 0;
bool haveDetectedPeak = false;
uint32_t beatSequence = 0;
uint32_t pendingBeatId = 0;
float pendingBeatBpm = 0.0f;
uint32_t heartRateWindowStart = 0;
uint16_t beatsInWindow = 0;
float thirtySecondBpm = 0.0f;

uint32_t nextSampleTime;
bool leadsConnected = false;
bool pendingLeadState = false;
uint32_t pendingLeadStateSince = 0;
uint32_t lastDisconnectedReport = 0;

// ---------- Local status hardware ----------
bool buzzerMuted = false;
bool buzzerIsOn = false;
bool lastButtonReading = HIGH;
bool stableButtonState = HIGH;
uint32_t lastButtonChange = 0;
uint32_t lastBuzzerChange = 0;
const char* latestDisplayStatus = "WAITING";


void setColour(bool red, bool green, bool blue) {
  digitalWrite(RED_PIN, red ? HIGH : LOW);
  digitalWrite(GREEN_PIN, green ? HIGH : LOW);
  digitalWrite(BLUE_PIN, blue ? HIGH : LOW);
}


void setBuzzer(bool enabled) {
  const bool shouldSound = enabled && !buzzerMuted && leadsConnected;
  digitalWrite(BUZZER_PIN, shouldSound ? HIGH : LOW);
  buzzerIsOn = shouldSound;
}


void updateMuteButton() {
  const uint32_t now = millis();
  const bool reading = digitalRead(BUTTON_PIN);

  if (reading != lastButtonReading) {
    lastButtonReading = reading;
    lastButtonChange = now;
  }

  if (now - lastButtonChange >= BUTTON_DEBOUNCE_MS
      && reading != stableButtonState) {
    stableButtonState = reading;

    if (stableButtonState == LOW) {
      buzzerMuted = !buzzerMuted;
      setBuzzer(false);
      lastBuzzerChange = now;
    }
  }
}


void updateStatusOutputs() {
  if (!leadsConnected) {
    setColour(false, false, true);
    setBuzzer(false);
    return;
  }

  const bool abnormal = strcmp(latestDisplayStatus, "ABNORMAL") == 0;
  const bool uncertain = strcmp(latestDisplayStatus, "UNCERTAIN") == 0;

  if (abnormal) {
    setColour(true, false, false);
  } else if (uncertain) {
    setColour(true, true, false);
  } else {
    setColour(false, true, false);
  }

  if (buzzerMuted) {
    setBuzzer(false);
    return;
  }

  const uint32_t now = millis();
  const uint32_t onTime = abnormal ? ALARM_BEEP_ON_MS : NORMAL_BEEP_ON_MS;
  const uint32_t offTime = abnormal ? ALARM_BEEP_OFF_MS : NORMAL_BEEP_OFF_MS;

  if (buzzerIsOn && now - lastBuzzerChange >= onTime) {
    setBuzzer(false);
    lastBuzzerChange = now;
  } else if (!buzzerIsOn && now - lastBuzzerChange >= offTime) {
    setBuzzer(true);
    lastBuzzerChange = now;
  }
}


void resetAcquisitionState() {
  historyWriteIndex = 0;
  samplesReceived = 0;
  heartbeatPosition = 0;
  collectingHeartbeat = false;
  sampleTwoBack = 0;
  sampleOneBack = 0;
  deviationTwoBack = 0.0f;
  deviationOneBack = 0.0f;
  runningBaseline = 2048.0f;
  signalLevel = 300.0f;
  noiseLevel = 40.0f;
  slopeLevel = 50.0f;
  detectorInitialized = false;
  haveTwoPreviousSamples = false;
  lastPeakSample = 0;
  haveDetectedPeak = false;
  pendingBeatId = 0;
  pendingBeatBpm = 0.0f;
  heartRateWindowStart = millis();
  beatsInWindow = 0;
  thirtySecondBpm = 0.0f;
  bandPassLowPass.reset();
  bandPassHighPass.reset();
  mainsNotch50Hz.reset();
}


void updateThirtySecondHeartRate() {
  const uint32_t now = millis();
  const uint32_t elapsed = now - heartRateWindowStart;

  if (elapsed < HEART_RATE_WINDOW_MS) {
    return;
  }

  // Count detected R-peaks for a complete 30-second observation window.
  // Using the actual elapsed time keeps the result correct if a loop is late.
  thirtySecondBpm = beatsInWindow * (60000.0f / (float) elapsed);

  Serial.print("BPM30,");
  Serial.print(thirtySecondBpm, 1);
  Serial.print(",");
  Serial.println(beatsInWindow);

  beatsInWindow = 0;
  heartRateWindowStart = now;
}


bool readLeadsConnected() {
  // The AD8232 drives either lead-off output HIGH when an electrode is off.
  return digitalRead(LO_PLUS_PIN) == LOW
      && digitalRead(LO_MINUS_PIN) == LOW;
}


void updateLeadState() {
  const bool measuredState = readLeadsConnected();

  if (measuredState != pendingLeadState) {
    pendingLeadState = measuredState;
    pendingLeadStateSince = millis();
    return;
  }

  if (measuredState != leadsConnected
      && millis() - pendingLeadStateSince >= LEAD_DEBOUNCE_MS) {
    leadsConnected = measuredState;
    resetAcquisitionState();
    nextSampleTime = micros();

    if (leadsConnected) {
      latestDisplayStatus = "WAITING";
      Serial.println("LEADS,CONNECTED");
    }
    else {
      latestDisplayStatus = "DISCONNECTED";
      setBuzzer(false);
      Serial.println("LEADS,DISCONNECTED");
      lastDisconnectedReport = millis();
    }
  }
}


int historyValueBack(int samplesBack) {
  int index = historyWriteIndex - 1 - samplesBack;

  while (index < 0) {
    index += HISTORY_SIZE;
  }

  return historyBuffer[index];
}


void prepareModelInput() {
  int clippedCount = 0;
  float sum = 0.0f;

  for (int i = 0; i < MODEL_INPUTS; i++) {
    sum += heartbeat[i];
    if (heartbeat[i] <= 5.0f || heartbeat[i] >= 4090.0f) {
      clippedCount++;
    }
  }

  if (clippedCount > 2) {
    Serial.println("SIGNAL,CLIPPED");
    Serial.println("Beat rejected: ADC clipping detected.");
    return;
  }

  const float liveMean = sum / MODEL_INPUTS;
  float squaredDifferenceSum = 0.0f;

  for (int i = 0; i < MODEL_INPUTS; i++) {
    const float difference = heartbeat[i] - liveMean;
    squaredDifferenceSum += difference * difference;
  }

  const float liveStd = sqrtf(squaredDifferenceSum / MODEL_INPUTS);

  if (liveStd < 1.0f) {
    Serial.println("Beat rejected: signal variation is too small.");
    return;
  }

  // The standardized model was trained with each heartbeat transformed using:
  // (sample - beat mean) / (beat standard deviation + epsilon).
  for (int i = 0; i < MODEL_INPUTS; i++) {
    modelInput[i] = (heartbeat[i] - liveMean)
                    / (liveStd + STANDARDIZATION_EPSILON);
  }

  if (!ml.predict(modelInput).isOk()) {
    Serial.print("ERROR: Inference failed: ");
    Serial.println(ml.exception.toString());
    return;
  }

  const float prediction = ml.output(0);
  const char* classification;

  if (prediction <= ECG_UNCERTAIN_LOW) {
    classification = "NORMAL (N-like)";
    latestDisplayStatus = "NORMAL";
  } else if (prediction >= ECG_UNCERTAIN_HIGH) {
    classification = "ABNORMAL (V-like)";
    latestDisplayStatus = "ABNORMAL";
  } else {
    classification = "UNCERTAIN";
    latestDisplayStatus = "UNCERTAIN";
  }

  // Send the beat ID, BPM and AI output together. This guarantees that Flask
  // never joins a prediction to the BPM from a different heartbeat.
  Serial.print("RESULT,");
  Serial.print(pendingBeatId);
  Serial.print(",");
  Serial.print(pendingBeatBpm, 2);
  Serial.print(",");
  Serial.print(prediction, 6);
  Serial.print(",");
  Serial.println(classification);
}


void processSample(int rawSample, int currentSample) {
  // Flask receives the filtered waveform in the normal 0-4095 display range.
  Serial.print("ECG,");
  Serial.println(currentSample);

  // Keep raw samples for the current AI model because its training dataset
  // did not include this new embedded filter.
  historyBuffer[historyWriteIndex] = rawSample;
  historyWriteIndex = (historyWriteIndex + 1) % HISTORY_SIZE;
  samplesReceived++;

  if (!detectorInitialized) {
    runningBaseline = currentSample;
    detectorInitialized = true;
  }

  runningBaseline += BASELINE_ALPHA * (currentSample - runningBaseline);
  const float currentDeviation = fabsf(currentSample - runningBaseline);

  // Finish collecting samples after an already-detected peak.
  if (collectingHeartbeat) {
    heartbeat[heartbeatPosition++] = rawSample;

    if (heartbeatPosition == MODEL_INPUTS) {
      collectingHeartbeat = false;
      prepareModelInput();
    }
  }

  if (!haveTwoPreviousSamples) {
    if (samplesReceived == 1) {
      sampleOneBack = currentSample;
      deviationOneBack = currentDeviation;
    }
    else {
      sampleTwoBack = sampleOneBack;
      sampleOneBack = currentSample;
      deviationTwoBack = deviationOneBack;
      deviationOneBack = currentDeviation;
      haveTwoPreviousSamples = true;
    }
    return;
  }

  // sampleOneBack is the local-maximum candidate; currentSample confirms it.
  const uint32_t candidateIndex = samplesReceived - 2;
  const bool refractoryComplete = !haveDetectedPeak
      || (candidateIndex - lastPeakSample > REFRACTORY_SAMPLES);

  const float adaptiveThreshold = fmaxf(
      MIN_PEAK_DEVIATION,
      noiseLevel + 0.35f * (signalLevel - noiseLevel));
  const float candidateSlope = fabsf(sampleOneBack - sampleTwoBack);
  const float adaptiveSlope = fmaxf(MIN_PEAK_SLOPE, 0.35f * slopeLevel);

  // Using absolute deviation detects both upright and inverted R-peaks.
  const bool isPeak = deviationOneBack > adaptiveThreshold
      && deviationOneBack > deviationTwoBack
      && deviationOneBack > currentDeviation
      && candidateSlope > adaptiveSlope
      && refractoryComplete;

  if (isPeak && !collectingHeartbeat && samplesReceived >= 92) {
    pendingBeatId = ++beatSequence;
    pendingBeatBpm = thirtySecondBpm;
    beatsInWindow++;

    // Copy candidate-90 through candidate into positions 0 through 90.
    for (int i = 0; i <= PEAK_POSITION; i++) {
      const int samplesBackFromCurrent = (PEAK_POSITION + 1) - i;
      heartbeat[i] = historyValueBack(samplesBackFromCurrent);
    }

    // rawSample is the first raw sample after the detected peak.
    heartbeat[PEAK_POSITION + 1] = rawSample;
    heartbeatPosition = PEAK_POSITION + 2;
    collectingHeartbeat = true;
    lastPeakSample = candidateIndex;
    haveDetectedPeak = true;

    signalLevel = 0.875f * signalLevel + 0.125f * deviationOneBack;
    slopeLevel = 0.875f * slopeLevel + 0.125f * candidateSlope;

    Serial.print("R-peak detected: ");
    Serial.println(sampleOneBack);
  }
  else {
    noiseLevel = 0.995f * noiseLevel + 0.005f * deviationOneBack;
  }

  sampleTwoBack = sampleOneBack;
  sampleOneBack = currentSample;
  deviationTwoBack = deviationOneBack;
  deviationOneBack = currentDeviation;
}


void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  pinMode(LO_PLUS_PIN, INPUT_PULLUP);
  pinMode(LO_MINUS_PIN, INPUT_PULLUP);
  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  setBuzzer(false);
  setColour(false, false, true);
  delay(1500);

  Serial.println("--- Phase 4: Live ECG TinyML Inference ---");

  ml.setNumInputs(MODEL_INPUTS);
  ml.setNumOutputs(MODEL_OUTPUTS);

  // Operators contained in this exact model.h file.
  ml.resolver.AddExpandDims();
  ml.resolver.AddConv2D();
  ml.resolver.AddReshape();
  ml.resolver.AddMaxPool2D();
  ml.resolver.AddShape();
  ml.resolver.AddStridedSlice();
  ml.resolver.AddPack();
  ml.resolver.AddFullyConnected();
  ml.resolver.AddLogistic();

  if (!ml.begin(heart_model_standardized_tflite).isOk()) {
    Serial.print("ERROR: TensorFlow Lite model initialization failed: ");
    Serial.println(ml.exception.toString());
    while (true) {
      delay(1000);
    }
  }

  Serial.println("Model initialized: input [1, 200, 1], float32");
  leadsConnected = readLeadsConnected();
  latestDisplayStatus = leadsConnected ? "WAITING" : "DISCONNECTED";
  pendingLeadState = leadsConnected;
  pendingLeadStateSince = millis();
  Serial.println(leadsConnected ? "LEADS,CONNECTED" : "LEADS,DISCONNECTED");
  if (!leadsConnected) {
    lastDisconnectedReport = millis();
  }
  Serial.println("Waiting for valid ECG R-peaks...");
  nextSampleTime = micros();
}


void loop() {
  updateMuteButton();
  updateLeadState();
  updateStatusOutputs();

  if (!leadsConnected) {
    // Repeat this state because Flask may open the port after the startup
    // message was sent or clear its serial input buffer while connecting.
    if (millis() - lastDisconnectedReport >= DISCONNECTED_REPORT_INTERVAL_MS) {
      Serial.println("LEADS,DISCONNECTED");
      lastDisconnectedReport = millis();
    }

    // Do not send noise to Flask or run the AI while electrodes are off.
    nextSampleTime = micros() + SAMPLE_PERIOD_US;
    delay(2);
    return;
  }

  updateThirtySecondHeartRate();

  const uint32_t now = micros();

  if ((int32_t)(now - nextSampleTime) >= 0) {
    nextSampleTime += SAMPLE_PERIOD_US;
    const int rawSample = analogRead(ECG_PIN);
    const float filteredCentered = filterEcg(rawSample);
    const int filteredForDisplay = constrain(
        (int) lroundf(filteredCentered + 2048.0f), 0, 4095);
    processSample(rawSample, filteredForDisplay);
  }
}
